#!/bin/bash

# ==============================================================================
# SCRIPT : SENTINEL ENTERPRISE v4.0
# ADMIN  : YOUSSEF | IPSSI SECTION
# ==============================================================================

# --- Configuration Couleurs & Environnement ---
export LANG=fr_FR.UTF-8
CYAN='\033[0;36m'
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
WHITE='\033[1;37m'
PURPLE='\033[0;35m'
BLUE='\033[0;34m'
NC='\033[0m'

tput civis
trap "tput cnorm; clear; exit" SIGINT

# --- Variables d'état ---
LAST_MSG="Système Sentinel opérationnel."
METEO="Nice: $(curl -s --connect-timeout 2 'wttr.in/Nice?format=%t' 2>/dev/null || echo '☀️ +16°C')"

# --- FONCTIONS TECHNIQUES ---

# 10. Smart Backup avec Hash
run_smart_backup() {
    local BACKUP_DIR="archives_$(date +%d%m)"
    mkdir -p "$BACKUP_DIR"
    local archive_name="$BACKUP_DIR/backup_$(date +%H%M).tar.gz"
    
    LAST_MSG="Compression en cours..."
    tar -czf "$archive_name" *.sh *.csv *.log 2>/dev/null
    
    local size=$(du -h "$archive_name" | awk '{print $1}')
    local hash_val=$(sha256sum "$archive_name" | awk '{print $1}' | cut -c1-8)
    LAST_MSG="Backup OK ($size) | Hash SHA256: $hash_val"
}

# 11. Monitoring des Services
check_services_status() {
    local ssh_s=$(pgrep sshd >/dev/null && echo -e "${GREEN}UP${NC}" || echo -e "${RED}DOWN${NC}")
    local cron_s=$(pgrep cron >/dev/null && echo -e "${GREEN}UP${NC}" || echo -e "${RED}DOWN${NC}")
    local ufw_s=$(sudo ufw status 2>/dev/null | grep -q "active" && echo -e "${GREEN}ON${NC}" || echo -e "${RED}OFF${NC}")
    LAST_MSG="Srv: SSH[$ssh_s] Cron[$cron_s] Firewall[$ufw_s]"
}

# --- INTERFACE GRAPHIQUE (DESIGN RÉORGANISÉ) ---

draw_ui() {
    clear
    # Header
    tput cup 0 2; echo -e "${YELLOW}System Operator: ${PURPLE}youssef${NC}"
    
    # Logo IPSSI
    tput cup 1 2; echo -e "${CYAN}  ██╗██████╗ ███████╗███████╗██╗"
    tput cup 2 2; echo -e "  ██║██╔══██╗██╔════╝██╔════╝██║"
    tput cup 3 2; echo -e "  ██║██████╔╝███████╗███████╗██║"
    tput cup 4 2; echo -e "  ██║██╔═══╝ ╚════██║╚════██║██║"
    tput cup 5 2; echo -e "  ██║██║     ███████║███████║██║"
    tput cup 6 2; echo -e "  ╚═╝╚═╝     ╚══════╝╚══════╝╚═╝${NC}"
    
    # Infos de droite (Monitoring)
    tput cup 2 45; echo -e "${BLUE}DATE   :${NC} $(date +'%d/%m/%Y')"
    tput cup 3 45; echo -e "${BLUE}CITY   :${NC} Nice, FR"
    tput cup 4 45; echo -e "${BLUE}METEO  :${NC} $METEO"
    
    # Séparateur
    tput cup 8 0; echo -e "${BLUE}======================================================================${NC}"
    
    # Menu principal (2 colonnes aérées)
    tput cup 10 2;  echo -e "${WHITE}1)${NC} SECURITY AUDIT (CSV)"    ; tput cup 10 35; echo -e "${WHITE}6)${NC} CLEAN TEMP FILES"
    tput cup 11 2;  echo -e "${WHITE}2)${NC} NETWORK DIAGNOSTIC"      ; tput cup 11 35; echo -e "${WHITE}7)${NC} TOP PROCESS ALERT"
    tput cup 12 2;  echo -e "${WHITE}3)${NC} USER PROVISIONING"       ; tput cup 12 35; echo -e "${WHITE}8)${NC} OPEN PORTS SCAN"
    tput cup 13 2;  echo -e "${WHITE}4)${NC} STORAGE ANALYZER"        ; tput cup 13 35; echo -e "${YELLOW}10) SMART BACKUP & HASH${NC}"
    tput cup 14 2;  echo -e "${WHITE}5)${NC} SYSTEM LOGS (Critical)"  ; tput cup 14 35; echo -e "${CYAN}11) MONITOR SERVICES${NC}"
    
    tput cup 16 2;  echo -e "${RED}9) EXIT SESSION${NC}"

    # Zone de Statut (Bas de page)
    tput cup 18 0; echo -e "${BLUE}----------------------------------------------------------------------${NC}"
}

# --- BOUCLE PRINCIPALE ---

draw_ui
while true; do
    # Mise à jour des KPIs (Santé du système)
    CUR_TIME=$(date +'%H:%M:%S')
    CPU=$(top -bn1 | grep "Cpu(s)" | awk '{print $2 + $4}')
    RAM=$(free | grep Mem | awk '{print int($3/$2 * 100)}')

    tput cup 5 45; echo -e "${BLUE}HEALTH :${NC} CPU:${CPU}% RAM:${RAM}%   "
    tput cup 2 54; echo -e "$(date +'%H:%M:%S')" # Update heure précise

    # Affichage du message de statut
    tput cup 19 2; tput el; echo -e "${WHITE}STATUS : ${GREEN}$LAST_MSG${NC}"
    tput cup 21 2; echo -ne "${BLUE}COMMAND > ${NC}"; tput el

    # Lecture commande
    read -t 1 -n 2 key
    
    case $key in
        1) echo "$(date);$USER;AUDIT" >> admin_audit.csv; LAST_MSG="Audit CSV exporté." ;;
        2) ping -c 1 8.8.8.8 >/dev/null && LAST_MSG="Réseau : Connecté (OK)" || LAST_MSG="Réseau : Échec (Vérifiez IP)" ;;
        3) U="u_$(date +%S)"; sudo useradd -m "$U" 2>/dev/null && LAST_MSG="User $U créé avec succès." || LAST_MSG="Erreur : Droits sudo requis." ;;
        4) LAST_MSG="Dossier lourd : $(du -sh ~/* 2>/dev/null | sort -rh | head -n 1)" ;;
        5) LAST_MSG="Log : $(journalctl -p 3 -n 1 --no-pager | tail -c 45)" ;;
        6) find /tmp -type f -atime +1 -delete 2>/dev/null; LAST_MSG="Fichiers temporaires nettoyés." ;;
        7) LAST_MSG="CPU Alert : $(ps -eo comm --sort=-%cpu | head -n 2 | tail -n 1) est gourmand." ;;
        8) LAST_MSG="Ports Listen : $(ss -tln | grep LISTEN | awk '{print $4}' | awk -F':' '{print $NF}' | xargs)" ;;
        10) run_smart_backup ;;
        11) check_services_status ;;
        9) tput cnorm; clear; exit 0 ;;
    esac
done
