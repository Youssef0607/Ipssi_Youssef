#!/bin/bash

# --- Configuration ---
export LANG=fr_FR.UTF-8
CYAN='\033[0;36m'
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
WHITE='\033[1;37m'
PURPLE='\033[0;35m'
BLUE='\033[0;34m'
NC='\033[0m'

tput civis
trap "tput cnorm; clear; exit" SIGINT

LAST_MSG="Console Enterprise prête."
WEATHER="Nice: ☀️ +16°C"

# --- NOUVELLE FONCTION : SMART BACKUP ---
run_smart_backup() {
    LAST_MSG="Préparation de la sauvegarde..."
    BACKUP_DIR="archives_$(date +%d%m)"
    mkdir -p "$BACKUP_DIR"
    
    # On compresse le répertoire courant (ton projet)
    # Utilité : Sécurité des données avant modification
    local archive_name="$BACKUP_DIR/backup_$(date +%H%M).tar.gz"
    
    tar -czf "$archive_name" *.sh *.csv *.log 2>/dev/null
    
    # Calcul du Hash (Preuve d'intégrité - argument pro)
    local hash_val=$(sha256sum "$archive_name" | awk '{print $1}' | cut -c1-16)
    
    LAST_MSG="Backup créé : $archive_name | Hash: $hash_val..."
}

# --- INTERFACE ---
draw_static_ui() {
    clear
    tput cup 0 2; echo -e "${YELLOW}System Operator: ${PURPLE}youssef${NC}"
    tput cup 1 2; echo -e "${CYAN}  ██╗██████╗ ███████╗███████╗██╗"
    tput cup 2 2; echo -e "  ██║██╔══██╗██╔════╝██╔════╝██║"
    tput cup 3 2; echo -e "  ██║██████╔╝███████╗███████╗██║"
    tput cup 4 2; echo -e "  ██║██╔═══╝ ╚════██║╚════██║██║"
    tput cup 5 2; echo -e "  ██║██║     ███████║███████║██║"
    tput cup 6 2; echo -e "  ╚═╝╚═╝     ╚══════╝╚══════╝╚═╝${NC}"
    tput cup 8 2; echo -e "${BLUE}================================================================${NC}"
    tput cup 11 4; echo -e "${WHITE}1)${NC} SECURITY AUDIT       ${WHITE}4)${NC} STORAGE ANALYZER"
    tput cup 12 4; echo -e "${WHITE}2)${NC} NETWORK DIAGNOSTIC   ${WHITE}5)${NC} SYSTEM LOGS"
    tput cup 13 4; echo -e "${WHITE}3)${NC} USER PROVISIONING    ${WHITE}6)${NC} CLEAN TEMP FILES"
    tput cup 14 4; echo -e "${WHITE}7)${NC} TOP PROCESS ALERT    ${WHITE}8)${NC} OPEN PORTS SCAN"
    tput cup 15 4; echo -e "${YELLOW}10) SMART BACKUP & HASH${NC}  ${RED}9) EXIT SESSION${NC}"
}

draw_static_ui
while true; do
    CUR_TIME=$(TZ='Europe/Paris' date +'%H:%M:%S')
    CPU_STAT=$(top -bn1 | grep "Cpu(s)" | awk '{print $2 + $4}')
    RAM_STAT=$(free | grep Mem | awk '{print int($3/$2 * 100)}')

    tput cup 2 45; echo -e "${YELLOW}TIME   :${NC} $CUR_TIME  "
    tput cup 3 45; echo -e "${YELLOW}CITY   :${NC} Nice, FR          "
    tput cup 4 45; echo -e "${YELLOW}HEALTH :${NC} CPU:${CPU_STAT}% RAM:${RAM_STAT}%   "

    tput cup 9 2; tput el; echo -e "${WHITE}STATUS : ${GREEN}$LAST_MSG${NC}"
    tput cup 18 2; echo -ne "${BLUE}COMMAND > ${NC}"

    read -t 0.8 -n 2 key
    case $key in
        1) echo "$(date);$USER;AUDIT" >> admin_audit.csv; LAST_MSG="Audit CSV généré." ;;
        2) ping -c 1 8.8.8.8 >/dev/null && LAST_MSG="Réseau OK" || LAST_MSG="Réseau DOWN" ;;
        3) U="u_$(date +%S)"; sudo useradd -m "$U" 2>/dev/null && LAST_MSG="User $U créé." || LAST_MSG="Erreur Sudo." ;;
        4) LAST_MSG="Top dossiers : $(du -sh ~/* 2>/dev/null | sort -rh | head -n 1)" ;;
        5) LAST_MSG="Dernier Log : $(journalctl -p 3 -n 1 --no-pager | tail -c 40)" ;;
        6) find /tmp -type f -atime +1 -delete 2>/dev/null; LAST_MSG="Système nettoyé." ;;
        7) LAST_MSG="Top Proc : $(ps -eo comm --sort=-%cpu | head -n 2 | tail -n 1)" ;;
        8) LAST_MSG="Ports : $(ss -tln | grep LISTEN | awk '{print $4}' | awk -F':' '{print $NF}' | xargs)" ;;
        10) run_smart_backup ;;
        9) tput cnorm; clear; exit 0 ;;
    esac
done
